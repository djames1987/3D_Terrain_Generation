use pyo3::prelude::*;
use noise::{NoiseFn, Perlin, Seedable};

#[pyclass]
#[pyo3(text_signature = "(map_size=500.0, max_height=100)")]
pub struct MapDataGenerator {
    map_size: f64,
    max_height: usize,
}

#[pymethods]
impl MapDataGenerator {
    #[new]
    fn new(map_size: f64, max_height: usize) -> Self {
        Self { map_size, max_height }
    }

    fn generate_map_data(&self) -> PyResult<Vec<Vec<Vec<f64>>>> {
        let scale = self.map_size / 10.0;

        let octaves = 6;
        let persistence = 0.5;
        let lacunarity = 2.0;

        let perlin = Perlin::new().set_seed(0);

        let mut data = vec![vec![vec![0.0; self.map_size as usize]; self.map_size as usize]; self.max_height];

        for z in 0..self.max_height {
            for y in 0..self.map_size as usize {
                for x in 0..self.map_size as usize {
                    let mut max_value = 0.0;
                    let mut amplitude = 1.0;
                    let mut frequency = 1.0;
                    let mut total = 0.0;
                    for _o in 0..octaves {
                        let h = amplitude * perlin.get([((x as f64) * frequency / scale) % 1024.0, ((y as f64) * frequency / scale) % 1024.0]);
                        total += h;
                        max_value += amplitude;

                        amplitude *= persistence;
                        frequency *= lacunarity;
                    }

                    let mut h = total / max_value;
                    h = (h + 1.0) / 2.0; // scale from -1..1 to 0..1
                    h *= self.max_height as f64;

                    data[z][y][x] = h;
                }
            }
        }

        Ok(data)
    }
}

/// A Python module implemented in Rust.
#[pymodule]
fn rust_noise(py: Python, m: &PyModule) -> PyResult<()> {
    m.add_class::<MapDataGenerator>()?;
    Ok(())
}